import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Target, Users, CheckCircle, Lightbulb, BookOpen, MessageCircle } from "lucide-react";

const About = () => {
  const objectives = [
    {
      icon: Target,
      title: "Bridge Knowledge Gaps",
      description: "Help recruiters understand technical concepts without becoming developers themselves."
    },
    {
      icon: Users,
      title: "Improve Candidate Conversations",
      description: "Speak confidently with technical candidates and ask relevant, insightful questions."
    },
    {
      icon: CheckCircle,
      title: "Better Hiring Decisions",
      description: "Evaluate candidates more effectively by understanding what skills actually matter."
    },
    {
      icon: Lightbulb,
      title: "Stay Current",
      description: "Keep up with technology trends from legacy systems to emerging technologies."
    }
  ];

  const howToUse = [
    {
      step: "1",
      title: "Learn the Fundamentals",
      description: "Start with Module 1-3 to understand basic concepts and terminology. Don't rush - take notes."
    },
    {
      step: "2",
      title: "Focus on Relevant Areas",
      description: "Deep dive into modules related to your recruitment focus (e.g., Cloud for cloud roles)."
    },
    {
      step: "3",
      title: "Test Your Knowledge",
      description: "Use quizzes to reinforce learning. Revisit explanations for questions you miss."
    },
    {
      step: "4",
      title: "Apply in Screening",
      description: "Use your knowledge to craft better job descriptions and screening questions."
    },
    {
      step: "5",
      title: "Continuous Learning",
      description: "Revisit modules regularly. Technology evolves - stay updated with new content."
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            About This Program
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Empowering recruiters with the technology knowledge needed to excel
            in today's competitive hiring landscape.
          </p>
        </div>

        {/* Purpose */}
        <Card className="mb-12 shadow-md">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold mb-6">Purpose & Vision</h2>
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                In today's rapidly evolving tech landscape, recruiters face a unique challenge:
                finding the right technical talent without necessarily having a technical background.
                This creates a knowledge gap that can lead to mismatched hires, poor candidate
                experiences, and missed opportunities.
              </p>
              <p>
                This comprehensive training program is designed specifically for recruitment
                professionals who want to <strong className="text-foreground">understand technology
                without becoming technologists</strong>. Our goal is to equip you with the knowledge
                to have confident, meaningful conversations with candidates and make informed hiring
                recommendations.
              </p>
              <p>
                We've carefully curated 15 modules covering everything from legacy systems that
                still power critical infrastructure to emerging technologies shaping the future.
                Each module is written in plain language, avoiding unnecessary jargon, with
                practical explanations that relate to real-world scenarios.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Objectives */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-8 text-center">What You'll Achieve</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {objectives.map((obj, idx) => (
              <Card key={idx} className="shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary/10 text-primary rounded-xl shrink-0">
                      <obj.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">{obj.title}</h3>
                      <p className="text-muted-foreground">{obj.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* How to Use */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-8 text-center">How to Use This Curriculum</h2>
          <div className="space-y-6">
            {howToUse.map((item, idx) => (
              <Card key={idx} className="shadow-md">
                <CardContent className="p-6">
                  <div className="flex items-start gap-6">
                    <div className="text-4xl font-bold text-primary/20 shrink-0">
                      {item.step}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                      <p className="text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* In Interviews */}
        <Card className="mb-12 shadow-md bg-gradient-to-br from-primary/5 to-secondary/5">
          <CardContent className="p-8">
            <div className="flex items-start gap-4 mb-6">
              <div className="p-3 bg-primary text-primary-foreground rounded-xl">
                <MessageCircle className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-3xl font-bold mb-2">Using This in Interviews</h2>
                <p className="text-muted-foreground text-lg">
                  Practical tips for applying your knowledge during candidate screening
                </p>
              </div>
            </div>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex gap-3">
                <CheckCircle className="h-6 w-6 text-secondary shrink-0" />
                <span><strong>Ask about real experience:</strong> "Can you tell me about a time you worked with microservices?" instead of "Do you know microservices?"</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="h-6 w-6 text-secondary shrink-0" />
                <span><strong>Understand depth vs breadth:</strong> A full-stack developer should know multiple areas; a specialist should go deep in their domain.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="h-6 w-6 text-secondary shrink-0" />
                <span><strong>Listen for context:</strong> How they explain concepts shows communication skills - critical for senior roles.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="h-6 w-6 text-secondary shrink-0" />
                <span><strong>Verify claims gently:</strong> If someone claims 10 years of Kubernetes experience, that's a red flag (Kubernetes was released in 2014).</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="h-6 w-6 text-secondary shrink-0" />
                <span><strong>Partner with hiring managers:</strong> Use your knowledge to facilitate better conversations, not replace technical assessments.</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* CTA */}
        <Card className="shadow-lg bg-gradient-to-br from-primary via-secondary to-accent text-white">
          <CardContent className="p-8 text-center">
            <BookOpen className="h-16 w-16 mx-auto mb-4 opacity-90" />
            <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-xl mb-6 opacity-90">
              Begin your journey to becoming a more confident, effective technical recruiter.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="secondary"
                className="gap-2 font-semibold"
                asChild
              >
                <Link to="/curriculum">
                  <BookOpen className="h-5 w-5" />
                  Start Learning
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2 font-semibold bg-white/10 border-white/30 hover:bg-white/20"
                asChild
              >
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default About;
