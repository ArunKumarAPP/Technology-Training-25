export interface Topic {
  title: string;
  description: string;
}

export interface Module {
  id: string;
  number: number;
  title: string;
  icon: string;
  color: string;
  topics: Topic[];
}

export const curriculumModules: Module[] = [
  {
    id: "foundations",
    number: 1,
    title: "Foundations & Legacy Technologies",
    icon: "Database",
    color: "bg-blue-500",
    topics: [
      {
        title: "Introduction to Software & SDLC",
        description: "Understanding the Software Development Life Cycle - how software is planned, built, tested, and maintained. Think of it as the recipe that teams follow to create reliable applications."
      },
      {
        title: "COBOL & Mainframe Basics",
        description: "COBOL powers many banking and government systems still in use today. Mainframes are large, powerful computers that handle millions of transactions securely - like the backbone of financial institutions."
      },
      {
        title: "AS/400 & Legacy System Concepts",
        description: "AS/400 (now IBM i) systems are reliable platforms used in manufacturing and retail. Legacy systems are older but proven technologies that companies still depend on for critical operations."
      },
      {
        title: "Client-Server Architecture",
        description: "A model where client computers request services from powerful server computers. Like a restaurant: clients are customers, servers provide the food, and the kitchen is the backend processing."
      },
      {
        title: "Databases & SQL Fundamentals",
        description: "Databases store organized information (like customer records). SQL is the language used to ask questions of databases - similar to searching in a very organized filing cabinet."
      }
    ]
  },
  {
    id: "business-roles",
    number: 2,
    title: "Business Roles & Product Roles",
    icon: "Users",
    color: "bg-purple-500",
    topics: [
      {
        title: "Business Analyst (BA)",
        description: "BAs bridge business needs and technical solutions. They gather requirements from stakeholders and translate them into clear specifications for development teams."
      },
      {
        title: "Systems Analyst",
        description: "Systems Analysts study existing systems and design improvements. They focus on how different technology components work together to solve business problems."
      },
      {
        title: "Product Owner",
        description: "Product Owners define what features should be built and prioritize work. They represent customer needs and make decisions about product direction within Agile teams."
      },
      {
        title: "Product Manager",
        description: "Product Managers own the product strategy and roadmap. They conduct market research, define product vision, and coordinate across teams to deliver successful products."
      },
      {
        title: "Scrum Master / Agile Coach",
        description: "Scrum Masters facilitate Agile processes and remove obstacles for teams. They coach teams on Agile practices and help improve collaboration and efficiency."
      }
    ]
  },
  {
    id: "dev-basics",
    number: 3,
    title: "Software Development Basics",
    icon: "Code",
    color: "bg-green-500",
    topics: [
      {
        title: "Programming Languages Overview",
        description: "C/C++ for systems programming, Java for enterprise apps, .NET for Microsoft ecosystems, Python for data and automation, JavaScript for web. Each language has strengths for different use cases."
      },
      {
        title: "Frontend vs Backend vs Full-Stack",
        description: "Frontend is what users see and interact with (buttons, forms). Backend handles data and business logic behind the scenes. Full-stack developers work on both sides."
      },
      {
        title: "API Basics (REST, SOAP)",
        description: "APIs are like menus that let different software talk to each other. REST is modern and flexible; SOAP is older but more structured. Both enable systems to share data and functionality."
      }
    ]
  },
  {
    id: "ui-ux",
    number: 4,
    title: "UI/UX & Design",
    icon: "Palette",
    color: "bg-pink-500",
    topics: [
      {
        title: "UI vs UX – Difference",
        description: "UI (User Interface) is how things look - colors, buttons, layout. UX (User Experience) is how things feel - ease of use, flow, satisfaction. Good products need both."
      },
      {
        title: "Wireframing (Figma, Sketch)",
        description: "Wireframes are basic blueprints of screens before design. Tools like Figma and Sketch help designers create interactive mockups to test ideas before development."
      },
      {
        title: "Prototyping",
        description: "Prototypes are clickable versions of designs that simulate the real product. They help teams test and validate ideas with users before investing in full development."
      },
      {
        title: "Design Systems & Accessibility",
        description: "Design systems are reusable component libraries ensuring consistency. Accessibility makes products usable by everyone, including people with disabilities - it's both ethical and legally required."
      },
      {
        title: "Interaction Design",
        description: "Interaction design focuses on how users interact with products - animations, transitions, feedback. Good interaction design makes products feel intuitive and delightful."
      },
      {
        title: "Product Design Basics",
        description: "Product designers combine UX research, UI design, and business thinking to create products that solve real problems and delight users while meeting business goals."
      }
    ]
  },
  {
    id: "frontend",
    number: 5,
    title: "Modern Frontend Technologies",
    icon: "Monitor",
    color: "bg-cyan-500",
    topics: [
      {
        title: "HTML/CSS/JavaScript",
        description: "HTML structures content (the skeleton), CSS styles it (the skin), JavaScript makes it interactive (the muscles). These are the core building blocks of every website."
      },
      {
        title: "Frameworks: React, Angular, Vue",
        description: "Modern frameworks speed up development and help build complex interfaces. React (by Meta) is most popular, Angular (by Google) is enterprise-focused, Vue is beginner-friendly."
      },
      {
        title: "Responsive Design",
        description: "Responsive design ensures websites work perfectly on all devices - phones, tablets, desktops. The layout automatically adjusts to different screen sizes."
      },
      {
        title: "Web Performance Optimization",
        description: "Making websites load faster improves user experience and SEO. Techniques include image optimization, code minification, caching, and lazy loading."
      }
    ]
  },
  {
    id: "backend",
    number: 6,
    title: "Backend & Server-Side Technologies",
    icon: "Server",
    color: "bg-indigo-500",
    topics: [
      {
        title: "Java/Spring Boot",
        description: "Java is widely used in enterprise applications. Spring Boot is a framework that simplifies building production-ready Java applications with less configuration."
      },
      {
        title: ".NET Core",
        description: "Microsoft's modern platform for building web apps, APIs, and services. Popular in enterprises using Microsoft ecosystems and supports cross-platform development."
      },
      {
        title: "Node.js",
        description: "Allows JavaScript to run on servers, not just browsers. Great for real-time applications and when you want to use JavaScript for both frontend and backend."
      },
      {
        title: "Python/Django/Flask",
        description: "Python is versatile and readable. Django is a full-featured web framework for rapid development. Flask is lightweight and flexible for smaller projects or APIs."
      },
      {
        title: "PHP/Laravel",
        description: "PHP powers many websites including WordPress. Laravel is a modern PHP framework that makes development elegant and efficient with built-in features."
      },
      {
        title: "Microservices Architecture",
        description: "Breaking large applications into small, independent services that communicate via APIs. This makes systems more scalable, flexible, and easier to maintain."
      }
    ]
  },
  {
    id: "databases",
    number: 7,
    title: "Databases & Data Technologies",
    icon: "Database",
    color: "bg-yellow-600",
    topics: [
      {
        title: "SQL Databases",
        description: "Relational databases organize data in tables with relationships. Oracle, MySQL, PostgreSQL, and SQL Server are popular choices for structured data and complex queries."
      },
      {
        title: "NoSQL Databases",
        description: "Flexible databases for unstructured data. MongoDB stores documents, Cassandra handles massive scale, DynamoDB is Amazon's managed NoSQL - great for modern applications."
      },
      {
        title: "Data Warehousing",
        description: "Centralized repositories for business data from multiple sources. Used for reporting and analysis to support strategic decisions - think of it as your company's data library."
      },
      {
        title: "ETL / ELT Concepts",
        description: "ETL (Extract, Transform, Load) and ELT move data between systems. They clean and organize data so it's ready for analysis and reporting."
      },
      {
        title: "Big Data (Hadoop, Spark)",
        description: "Technologies for processing massive datasets that don't fit on one computer. Hadoop stores huge amounts of data; Spark processes it quickly. Used by companies analyzing petabytes of information."
      }
    ]
  },
  {
    id: "cloud",
    number: 8,
    title: "Cloud Technologies",
    icon: "Cloud",
    color: "bg-sky-500",
    topics: [
      {
        title: "Cloud Basics (IaaS, PaaS, SaaS)",
        description: "IaaS provides servers (infrastructure), PaaS provides platforms for development, SaaS provides ready-to-use software. Cloud means renting computing resources instead of buying hardware."
      },
      {
        title: "AWS – Key Services",
        description: "Amazon's cloud platform offers EC2 (virtual servers), S3 (storage), RDS (databases), Lambda (serverless), and hundreds more services. Market leader with 30%+ share."
      },
      {
        title: "Azure – Key Services",
        description: "Microsoft's cloud integrates well with Windows and enterprise tools. Popular services include Virtual Machines, Azure SQL, and Active Directory. Strong in enterprise market."
      },
      {
        title: "GCP – Key Services",
        description: "Google's cloud excels in data analytics and machine learning. Offers Compute Engine, BigQuery, and strong Kubernetes support. Growing rapidly in market share."
      },
      {
        title: "Cloud Migration Concepts",
        description: "Moving applications from on-premise to cloud. Strategies include lift-and-shift (quick), re-platforming (some optimization), or complete re-architecture for cloud-native benefits."
      },
      {
        title: "Cloud Security Basics",
        description: "Protecting data and applications in the cloud through encryption, access controls, network security, and compliance. Shared responsibility between cloud provider and customer."
      }
    ]
  },
  {
    id: "devops",
    number: 9,
    title: "DevOps & Automation",
    icon: "GitBranch",
    color: "bg-orange-500",
    topics: [
      {
        title: "CI/CD Pipelines",
        description: "Continuous Integration/Continuous Deployment automates testing and deployment. Code changes are automatically tested and released, reducing errors and speeding up delivery."
      },
      {
        title: "Jenkins, GitLab, GitHub",
        description: "Tools for version control and CI/CD. GitHub stores code and facilitates collaboration, Jenkins automates builds and tests, GitLab offers integrated DevOps platform."
      },
      {
        title: "Containers: Docker",
        description: "Docker packages applications with all their dependencies into containers - lightweight, portable units that run consistently anywhere. Like shipping containers for software."
      },
      {
        title: "Kubernetes",
        description: "Orchestrates and manages containers at scale. Handles deployment, scaling, and operations of containerized applications across clusters of machines."
      },
      {
        title: "IaC: Terraform, Ansible",
        description: "Infrastructure as Code treats servers and networks like software. Terraform provisions cloud resources, Ansible configures systems - both enable version control and automation."
      },
      {
        title: "Observability: Grafana, Prometheus",
        description: "Monitoring tools that help teams understand system health and performance. Prometheus collects metrics, Grafana visualizes them - essential for maintaining reliable systems."
      }
    ]
  },
  {
    id: "ai-ml",
    number: 10,
    title: "AI, ML & Data Science",
    icon: "Brain",
    color: "bg-purple-600",
    topics: [
      {
        title: "What is AI?",
        description: "Artificial Intelligence is software that can perform tasks requiring human-like intelligence - recognizing images, understanding speech, making decisions. It learns from data rather than following rigid rules."
      },
      {
        title: "What is Machine Learning?",
        description: "Machine Learning is AI that improves through experience. Feed it data and it finds patterns - like teaching a child through examples rather than explicit instructions."
      },
      {
        title: "Generative AI Basics",
        description: "AI that creates new content - text, images, code, music. ChatGPT and DALL-E are examples. They learn from massive datasets and generate human-like outputs."
      },
      {
        title: "Prompt Engineering",
        description: "The skill of crafting effective instructions for AI models. Good prompts get better results - it's like knowing how to ask the right questions to get useful answers."
      },
      {
        title: "Data Modeling Basics",
        description: "Structuring data for analysis and machine learning. Involves selecting features, cleaning data, and preparing it for algorithms - the foundation of good ML results."
      },
      {
        title: "Tools: TensorFlow, PyTorch, OpenAI",
        description: "TensorFlow and PyTorch are ML frameworks for building models. OpenAI provides pre-trained models via APIs. These tools make AI accessible without PhD-level expertise."
      },
      {
        title: "AI Integration into Products",
        description: "Adding AI features to applications - chatbots, recommendations, image recognition. Involves choosing right models, integrating APIs, and ensuring good user experience."
      }
    ]
  },
  {
    id: "security",
    number: 11,
    title: "Cybersecurity Overview",
    icon: "Shield",
    color: "bg-red-500",
    topics: [
      {
        title: "Network Security Basics",
        description: "Protecting networks from unauthorized access through firewalls, VPNs, and intrusion detection. Like securing the doors and windows of your digital building."
      },
      {
        title: "Application Security",
        description: "Making software resistant to attacks through secure coding, input validation, and regular security testing. Prevents vulnerabilities like SQL injection and XSS."
      },
      {
        title: "Cloud Security",
        description: "Securing data and applications in cloud environments. Involves encryption, access controls, network security, and compliance with regulations like GDPR and HIPAA."
      },
      {
        title: "Security Tools (SIEM, SOC)",
        description: "SIEM systems collect and analyze security data from across infrastructure. SOC (Security Operations Center) teams monitor threats 24/7 and respond to incidents."
      },
      {
        title: "IAM (Identity & Access Management)",
        description: "Ensuring right people have right access to right resources. Includes authentication (proving who you are) and authorization (what you're allowed to do)."
      }
    ]
  },
  {
    id: "testing",
    number: 12,
    title: "Testing & Quality Engineering",
    icon: "CheckCircle",
    color: "bg-teal-500",
    topics: [
      {
        title: "Manual Testing",
        description: "Testers manually execute test cases to find bugs. Essential for usability, exploratory testing, and scenarios difficult to automate. Still valuable despite automation trends."
      },
      {
        title: "Automation Testing",
        description: "Using tools like Selenium and Cypress to automatically run tests. Faster and more reliable than manual testing for repetitive scenarios. Critical for CI/CD pipelines."
      },
      {
        title: "API Testing (Postman)",
        description: "Testing the backend APIs that power applications. Postman is popular for creating, running, and automating API tests without writing much code."
      },
      {
        title: "Performance Testing (JMeter)",
        description: "Testing how systems perform under load - speed, scalability, stability. JMeter simulates many users to find bottlenecks before they affect real users."
      },
      {
        title: "Security Testing (Pen Testing)",
        description: "Penetration testing simulates attacks to find vulnerabilities. Ethical hackers probe systems to discover weaknesses before malicious actors do."
      }
    ]
  },
  {
    id: "enterprise",
    number: 13,
    title: "Enterprise Systems & Platforms",
    icon: "Building",
    color: "bg-gray-600",
    topics: [
      {
        title: "ERP – SAP, Oracle",
        description: "Enterprise Resource Planning systems integrate all business processes - finance, HR, supply chain, manufacturing. SAP and Oracle dominate this massive market."
      },
      {
        title: "CRM – Salesforce, MS Dynamics",
        description: "Customer Relationship Management tracks interactions and sales. Salesforce is market leader; Microsoft Dynamics integrates well with Office ecosystem."
      },
      {
        title: "HCM – Workday, Oracle HCM",
        description: "Human Capital Management handles HR processes - recruiting, payroll, performance, benefits. Workday is modern cloud leader; Oracle serves large enterprises."
      },
      {
        title: "Integration – MuleSoft, Boomi, TIBCO",
        description: "Integration platforms connect different systems and applications. They enable data flow between cloud apps, on-premise systems, and databases without custom coding."
      },
      {
        title: "RPA – UiPath, Automation Anywhere",
        description: "Robotic Process Automation uses software bots to automate repetitive tasks. Like having digital workers handle data entry, form processing, and routine workflows."
      }
    ]
  },
  {
    id: "emerging",
    number: 14,
    title: "Emerging Technologies",
    icon: "Zap",
    color: "bg-fuchsia-500",
    topics: [
      {
        title: "Blockchain Basics",
        description: "Distributed ledger technology powering cryptocurrencies and smart contracts. Creates tamper-proof records without central authority - promising for supply chains, contracts, and finance."
      },
      {
        title: "IoT (Internet of Things)",
        description: "Connecting physical devices to the internet - smart homes, wearables, industrial sensors. Generates massive data for analytics and enables remote monitoring and control."
      },
      {
        title: "AR/VR (Augmented/Virtual Reality)",
        description: "AR overlays digital info on real world (think Pokemon Go). VR creates immersive digital environments. Used in gaming, training, design, and remote collaboration."
      },
      {
        title: "Robotics & Autonomous Systems",
        description: "Robots performing physical tasks autonomously - warehouse automation, self-driving cars, surgical robots. Combines AI, sensors, and mechanical engineering."
      },
      {
        title: "Quantum Computing (Simple)",
        description: "Extremely powerful computers using quantum mechanics. Still early but promises breakthroughs in cryptography, drug discovery, and complex simulations. Not replacing regular computers."
      }
    ]
  },
  {
    id: "industry",
    number: 15,
    title: "Industry-Specific Technology Trends",
    icon: "TrendingUp",
    color: "bg-emerald-600",
    topics: [
      {
        title: "BFSI (Banking, Financial Services, Insurance)",
        description: "Focus on core banking systems, digital payments, fraud detection, regulatory compliance (KYC/AML), blockchain for settlements, and AI for risk assessment."
      },
      {
        title: "Healthcare",
        description: "Electronic Health Records (EHR), telemedicine platforms, medical imaging AI, drug discovery ML, wearable devices, and HIPAA compliance for patient data."
      },
      {
        title: "Retail & E-Commerce",
        description: "Omnichannel platforms, personalization engines, inventory management, supply chain optimization, AR for virtual try-ons, and payment gateway integration."
      },
      {
        title: "Telecom",
        description: "5G networks, IoT connectivity, network function virtualization (NFV), OSS/BSS systems, edge computing, and customer experience platforms."
      },
      {
        title: "Manufacturing",
        description: "Industry 4.0, IoT sensors for predictive maintenance, digital twins, supply chain systems, quality control AI, and robotics for automation."
      }
    ]
  }
];
