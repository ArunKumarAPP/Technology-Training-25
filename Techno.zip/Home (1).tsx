import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Database,
  Cloud,
  Cpu,
  TrendingUp,
  Download,
  BookOpen,
  Lightbulb,
  Users,
} from "lucide-react";

const Home = () => {
  const features = [
    {
      icon: Database,
      title: "Foundations",
      description: "Master legacy systems, COBOL, mainframes, and fundamental software concepts.",
      color: "bg-primary/10 text-primary",
    },
    {
      icon: Cloud,
      title: "Modern Tech",
      description: "Explore cloud platforms, DevOps, containers, and modern development practices.",
      color: "bg-secondary/10 text-secondary",
    },
    {
      icon: Users,
      title: "Tech Roles",
      description: "Understand different technology roles from developers to product managers.",
      color: "bg-accent/10 text-accent",
    },
    {
      icon: TrendingUp,
      title: "Industry Trends",
      description: "Stay updated with AI, ML, blockchain, and emerging technologies.",
      color: "bg-primary/10 text-primary",
    },
  ];

  const timeline = [
    { year: "1960s-80s", tech: "COBOL & Mainframes", desc: "Legacy systems foundation" },
    { year: "1990s", tech: "Client-Server", desc: "Distributed computing era" },
    { year: "2000s", tech: "Web Technologies", desc: "Internet revolution" },
    { year: "2010s", tech: "Cloud & Mobile", desc: "Platform transformation" },
    { year: "2020s", tech: "AI & Edge Computing", desc: "Intelligent systems" },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5" />
        <div className="container mx-auto relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              Technology Training for{" "}
              <span className="gradient-text">Recruiters</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive curriculum to understand the technology landscape,
              speak confidently with candidates, and make informed hiring decisions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button size="lg" className="gap-2 font-semibold" asChild>
                <Link to="/curriculum">
                  <BookOpen className="h-5 w-5" />
                  View Curriculum
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="gap-2 font-semibold">
                <Download className="h-5 w-5" />
                Download PPT
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why This Training?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Bridge the knowledge gap between recruitment and technology. Understand
              what candidates actually do and what skills really matter.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="border-2 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <CardContent className="p-6 space-y-4">
                  <div className={`w-12 h-12 rounded-xl ${feature.color} flex items-center justify-center`}>
                    <feature.icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Technology Evolution
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Understanding how we got here helps you understand where we're going.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <div className="relative">
              {/* Timeline Line */}
              <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-border" />

              {/* Timeline Items */}
              <div className="space-y-12">
                {timeline.map((item, index) => (
                  <div
                    key={index}
                    className={`relative flex items-center gap-8 ${
                      index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                    }`}
                  >
                    {/* Timeline Dot */}
                    <div className="absolute left-8 md:left-1/2 w-4 h-4 bg-primary rounded-full -translate-x-[7px] ring-4 ring-background z-10" />

                    {/* Content */}
                    <div className="flex-1 ml-16 md:ml-0">
                      <Card
                        className={`${
                          index % 2 === 0 ? "md:mr-16" : "md:ml-16"
                        } hover:shadow-lg transition-all duration-300`}
                      >
                        <CardContent className="p-6">
                          <div className="font-semibold text-primary mb-1">
                            {item.year}
                          </div>
                          <h3 className="text-xl font-bold mb-2">{item.tech}</h3>
                          <p className="text-muted-foreground">{item.desc}</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary via-secondary to-accent text-white">
        <div className="container mx-auto text-center">
          <Lightbulb className="h-16 w-16 mx-auto mb-6 opacity-90" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Learning?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Dive into 15 comprehensive modules covering everything from legacy
            systems to emerging technologies.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              variant="secondary"
              className="gap-2 font-semibold"
              asChild
            >
              <Link to="/curriculum">
                <BookOpen className="h-5 w-5" />
                Explore Curriculum
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="gap-2 font-semibold bg-white/10 border-white/30 hover:bg-white/20"
              asChild
            >
              <Link to="/quizzes">Test Your Knowledge</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
