import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Download, CheckCircle, XCircle, ChevronRight } from "lucide-react";
import { quizzes } from "@/data/quizData";
import { toast } from "sonner";

const Quizzes = () => {
  const [selectedQuiz, setSelectedQuiz] = useState<string | null>(null);
  const [answers, setAnswers] = useState<{ [key: string]: number }>({});
  const [showResults, setShowResults] = useState<{ [key: string]: boolean }>({});

  const handleAnswer = (questionIdx: number, answerIdx: number) => {
    setAnswers({ ...answers, [`${selectedQuiz}-${questionIdx}`]: answerIdx });
  };

  const toggleResult = (questionIdx: number) => {
    const key = `${selectedQuiz}-${questionIdx}`;
    setShowResults({ ...showResults, [key]: !showResults[key] });
  };

  const calculateScore = (quiz: typeof quizzes[0]) => {
    let correct = 0;
    quiz.questions.forEach((q, idx) => {
      if (answers[`${quiz.moduleId}-${idx}`] === q.correctAnswer) {
        correct++;
      }
    });
    return { correct, total: quiz.questions.length };
  };

  const selectedQuizData = quizzes.find(q => q.moduleId === selectedQuiz);

  const handleDownloadQuiz = () => {
    toast.success("Quiz download will be available soon!");
  };

  if (!selectedQuiz) {
    return (
      <div className="min-h-screen pt-24 pb-20 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Test Your Knowledge
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              Reinforce your learning with module-wise quizzes. Each quiz contains
              3-5 multiple-choice questions to test your understanding.
            </p>
            <Button onClick={handleDownloadQuiz} className="gap-2">
              <Download className="h-5 w-5" />
              Download Complete Quiz Booklet (PDF)
            </Button>
          </div>

          {/* Quiz Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {quizzes.map((quiz) => {
              const score = calculateScore(quiz);
              const attempted = score.correct + 
                quiz.questions.filter((q, idx) => {
                  const ans = answers[`${quiz.moduleId}-${idx}`];
                  return ans !== undefined && ans !== q.correctAnswer;
                }).length;

              return (
                <Card
                  key={quiz.moduleId}
                  className="hover:shadow-lg transition-all cursor-pointer group"
                  onClick={() => setSelectedQuiz(quiz.moduleId)}
                >
                  <CardHeader>
                    <div className="flex justify-between items-start mb-2">
                      <Badge variant="secondary">
                        {quiz.questions.length} Questions
                      </Badge>
                      {attempted > 0 && (
                        <Badge variant={score.correct === quiz.questions.length ? "default" : "outline"}>
                          {score.correct}/{quiz.questions.length} Correct
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors">
                      {quiz.moduleTitle}
                    </CardTitle>
                    <CardDescription>
                      Test your understanding of {quiz.moduleTitle.toLowerCase()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="ghost" className="w-full gap-2 group-hover:bg-primary group-hover:text-primary-foreground">
                      Start Quiz
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  if (!selectedQuizData) return null;

  const score = calculateScore(selectedQuizData);

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-4xl">
        {/* Quiz Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setSelectedQuiz(null)}
            className="mb-4"
          >
            ← Back to All Quizzes
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            {selectedQuizData.moduleTitle}
          </h1>
          <p className="text-muted-foreground">
            Answer all questions and toggle to see explanations
          </p>
          {score.correct > 0 && (
            <Badge className="mt-4" variant={score.correct === score.total ? "default" : "secondary"}>
              Current Score: {score.correct}/{score.total}
            </Badge>
          )}
        </div>

        {/* Questions */}
        <div className="space-y-6">
          {selectedQuizData.questions.map((question, idx) => {
            const userAnswer = answers[`${selectedQuiz}-${idx}`];
            const showResult = showResults[`${selectedQuiz}-${idx}`];
            const isCorrect = userAnswer === question.correctAnswer;

            return (
              <Card key={idx} className="shadow-md">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <CardTitle className="text-lg">
                      Question {idx + 1}: {question.question}
                    </CardTitle>
                    {userAnswer !== undefined && (
                      <Badge variant={isCorrect ? "default" : "destructive"}>
                        {isCorrect ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <RadioGroup
                    value={userAnswer?.toString()}
                    onValueChange={(value) => handleAnswer(idx, parseInt(value))}
                  >
                    {question.options.map((option, optIdx) => (
                      <div
                        key={optIdx}
                        className={`flex items-center space-x-2 p-3 rounded-lg border ${
                          showResult && optIdx === question.correctAnswer
                            ? "border-secondary bg-secondary/10"
                            : showResult && optIdx === userAnswer && !isCorrect
                            ? "border-destructive bg-destructive/10"
                            : "border-border"
                        }`}
                      >
                        <RadioGroupItem value={optIdx.toString()} id={`q${idx}-opt${optIdx}`} />
                        <Label
                          htmlFor={`q${idx}-opt${optIdx}`}
                          className="flex-1 cursor-pointer"
                        >
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>

                  {userAnswer !== undefined && (
                    <Button
                      variant="outline"
                      onClick={() => toggleResult(idx)}
                      className="w-full"
                    >
                      {showResult ? "Hide" : "Show"} Answer & Explanation
                    </Button>
                  )}

                  {showResult && (
                    <div className="p-4 bg-muted rounded-lg space-y-2">
                      <div className="font-semibold flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-secondary" />
                        Correct Answer: {question.options[question.correctAnswer]}
                      </div>
                      <p className="text-muted-foreground">{question.explanation}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quiz Actions */}
        <div className="mt-8 flex flex-col sm:flex-row gap-4">
          <Button onClick={() => setSelectedQuiz(null)} variant="outline" className="gap-2">
            Back to Quiz List
          </Button>
          <Button onClick={handleDownloadQuiz} className="gap-2">
            <Download className="h-5 w-5" />
            Download This Quiz (PDF)
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Quizzes;
