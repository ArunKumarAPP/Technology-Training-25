import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Download, ExternalLink, BookOpen, FileText, Video, Link as LinkIcon, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const Resources = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const glossaryTerms = [
    { term: "API", definition: "Application Programming Interface - a way for different software to communicate with each other, like a menu in a restaurant." },
    { term: "Agile", definition: "A flexible approach to software development that works in short cycles (sprints) with continuous feedback and adaptation." },
    { term: "Backend", definition: "The server-side of an application that handles data processing, business logic, and database operations - what users don't see." },
    { term: "CI/CD", definition: "Continuous Integration/Continuous Deployment - automated testing and deployment of code changes for faster, reliable releases." },
    { term: "Cloud Computing", definition: "Using remote servers over the internet instead of local computers to store, manage, and process data." },
    { term: "Container", definition: "A lightweight package containing an application and all its dependencies, ensuring it runs consistently across different environments." },
    { term: "DevOps", definition: "Combining development and operations teams to automate and improve software delivery processes." },
    { term: "Frontend", definition: "The user-facing part of an application - everything users see and interact with in their browser or app." },
    { term: "Framework", definition: "Pre-built code structure that developers use as a foundation to build applications faster and with better consistency." },
    { term: "Microservices", definition: "Breaking large applications into small, independent services that can be developed and deployed separately." },
    { term: "REST API", definition: "A simple, standardized way for applications to communicate over the internet using HTTP requests." },
    { term: "SDK", definition: "Software Development Kit - a collection of tools, libraries, and documentation to help developers build applications for a specific platform." },
  ];

  const resources = [
    {
      category: "Documentation",
      items: [
        { name: "AWS Documentation", url: "https://docs.aws.amazon.com", icon: ExternalLink },
        { name: "Microsoft Azure Docs", url: "https://docs.microsoft.com/azure", icon: ExternalLink },
        { name: "React Official Docs", url: "https://react.dev", icon: ExternalLink },
        { name: "Python Beginner's Guide", url: "https://docs.python.org/3/tutorial/", icon: ExternalLink },
      ]
    },
    {
      category: "Learning Platforms",
      items: [
        { name: "Codecademy (Free Basics)", url: "https://www.codecademy.com", icon: BookOpen },
        { name: "freeCodeCamp", url: "https://www.freecodecamp.org", icon: BookOpen },
        { name: "Coursera Tech Courses", url: "https://www.coursera.org", icon: Video },
        { name: "LinkedIn Learning", url: "https://www.linkedin.com/learning", icon: Video },
      ]
    },
    {
      category: "Reference Sites",
      items: [
        { name: "MDN Web Docs", url: "https://developer.mozilla.org", icon: FileText },
        { name: "Stack Overflow", url: "https://stackoverflow.com", icon: LinkIcon },
        { name: "GitHub Guides", url: "https://guides.github.com", icon: FileText },
        { name: "TechTerms Dictionary", url: "https://techterms.com", icon: FileText },
      ]
    }
  ];

  const downloads = [
    { name: "Complete Curriculum (PPT)", icon: FileText, color: "bg-primary" },
    { name: "Complete Curriculum (PDF)", icon: FileText, color: "bg-secondary" },
    { name: "Quiz Booklet (PDF)", icon: FileText, color: "bg-accent" },
    { name: "Glossary Reference (PDF)", icon: FileText, color: "bg-primary" },
  ];

  const handleDownload = (name: string) => {
    toast.success(`${name} download will be available soon!`);
  };

  const filteredGlossary = glossaryTerms.filter(item =>
    item.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Learning Resources
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Curated collection of documentation, guides, and reference materials
            to deepen your technology knowledge.
          </p>
        </div>

        {/* Downloads Section */}
        <Card className="mb-12 shadow-md">
          <CardHeader>
            <CardTitle>Download Training Materials</CardTitle>
            <CardDescription>
              Get offline access to the complete curriculum and resources
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {downloads.map((item, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  className="h-auto py-4 flex-col gap-3 hover:shadow-md transition-all"
                  onClick={() => handleDownload(item.name)}
                >
                  <div className={`p-3 rounded-xl ${item.color} text-white`}>
                    <item.icon className="h-6 w-6" />
                  </div>
                  <span className="text-sm font-medium text-center">{item.name}</span>
                  <Download className="h-4 w-4 text-muted-foreground" />
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* External Resources */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-6">External Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {resources.map((section, idx) => (
              <Card key={idx} className="shadow-md">
                <CardHeader>
                  <CardTitle className="text-xl">{section.category}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {section.items.map((item, itemIdx) => (
                      <li key={itemIdx}>
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-primary hover:underline group"
                        >
                          <item.icon className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                          <span>{item.name}</span>
                        </a>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Glossary */}
        <div>
          <h2 className="text-3xl font-bold mb-6">Technology Glossary</h2>
          <Card className="shadow-md mb-6">
            <CardContent className="p-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search terms..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredGlossary.map((item, idx) => (
              <Card key={idx} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-3">
                    <Badge className="shrink-0">{item.term}</Badge>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {item.definition}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredGlossary.length === 0 && (
            <Card className="py-12">
              <CardContent className="text-center text-muted-foreground">
                No terms found matching your search.
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Resources;
