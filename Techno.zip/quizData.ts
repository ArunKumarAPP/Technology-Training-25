export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Quiz {
  moduleId: string;
  moduleTitle: string;
  questions: QuizQuestion[];
}

export const quizzes: Quiz[] = [
  {
    moduleId: "foundations",
    moduleTitle: "Foundations & Legacy Technologies",
    questions: [
      {
        question: "What does SDLC stand for in software development?",
        options: [
          "Software Design Life Cycle",
          "Software Development Life Cycle",
          "System Development Logic Code",
          "Standard Development Life Code"
        ],
        correctAnswer: 1,
        explanation: "SDLC stands for Software Development Life Cycle - the process teams follow to plan, create, test, and deploy software."
      },
      {
        question: "Which type of system is COBOL most commonly associated with?",
        options: [
          "Mobile applications",
          "Social media platforms",
          "Banking and financial systems",
          "Gaming engines"
        ],
        correctAnswer: 2,
        explanation: "COBOL is primarily used in banking, finance, and government systems where reliability and transaction processing are critical."
      },
      {
        question: "In client-server architecture, what does the server primarily do?",
        options: [
          "Display information to users",
          "Process requests and provide services",
          "Connect to the internet",
          "Store cookies"
        ],
        correctAnswer: 1,
        explanation: "Servers process requests from clients and provide services like data processing, storage, and business logic."
      }
    ]
  },
  {
    moduleId: "business-roles",
    moduleTitle: "Business Roles & Product Roles",
    questions: [
      {
        question: "What is the primary responsibility of a Product Owner in Agile?",
        options: [
          "Writing all the code",
          "Managing the team's budget",
          "Defining features and prioritizing work",
          "Testing the final product"
        ],
        correctAnswer: 2,
        explanation: "Product Owners define what features should be built and prioritize the work based on business value and customer needs."
      },
      {
        question: "Which role bridges the gap between business stakeholders and technical teams?",
        options: [
          "Scrum Master",
          "Business Analyst",
          "DevOps Engineer",
          "QA Tester"
        ],
        correctAnswer: 1,
        explanation: "Business Analysts gather requirements from stakeholders and translate them into specifications for development teams."
      },
      {
        question: "What is a Scrum Master's main focus?",
        options: [
          "Writing user stories",
          "Coding features",
          "Facilitating Agile processes and removing obstacles",
          "Designing the product"
        ],
        correctAnswer: 2,
        explanation: "Scrum Masters facilitate Agile ceremonies, remove impediments, and help teams improve their processes."
      }
    ]
  },
  {
    moduleId: "cloud",
    moduleTitle: "Cloud Technologies",
    questions: [
      {
        question: "What does IaaS stand for?",
        options: [
          "Internet as a Service",
          "Infrastructure as a Service",
          "Integration as a Service",
          "Information as a Service"
        ],
        correctAnswer: 1,
        explanation: "IaaS (Infrastructure as a Service) provides virtualized computing resources over the internet, like servers and storage."
      },
      {
        question: "Which cloud provider is the market leader with the largest market share?",
        options: [
          "Microsoft Azure",
          "Google Cloud Platform",
          "Amazon Web Services (AWS)",
          "IBM Cloud"
        ],
        correctAnswer: 2,
        explanation: "AWS (Amazon Web Services) is the market leader with approximately 30%+ market share in cloud computing."
      },
      {
        question: "What is the main benefit of cloud migration?",
        options: [
          "Eliminating all IT costs",
          "Scalability and flexibility without hardware investment",
          "Guaranteed faster performance",
          "No need for security measures"
        ],
        correctAnswer: 1,
        explanation: "Cloud migration provides scalability, flexibility, and eliminates the need for upfront hardware investment while enabling pay-as-you-go models."
      }
    ]
  },
  {
    moduleId: "ai-ml",
    moduleTitle: "AI, ML & Data Science",
    questions: [
      {
        question: "What is the primary difference between AI and Machine Learning?",
        options: [
          "There is no difference",
          "ML is a subset of AI that learns from data",
          "AI is newer than ML",
          "ML is only for image recognition"
        ],
        correctAnswer: 1,
        explanation: "Machine Learning is a subset of AI that focuses on systems that can learn and improve from experience without being explicitly programmed."
      },
      {
        question: "What is Generative AI best known for?",
        options: [
          "Analyzing existing data only",
          "Creating new content like text, images, and code",
          "Deleting unnecessary files",
          "Optimizing hardware performance"
        ],
        correctAnswer: 1,
        explanation: "Generative AI creates new content based on patterns learned from training data - including text (ChatGPT), images (DALL-E), and code."
      },
      {
        question: "What is Prompt Engineering?",
        options: [
          "Building AI hardware",
          "Crafting effective instructions for AI models",
          "Programming in Python",
          "Designing databases"
        ],
        correctAnswer: 1,
        explanation: "Prompt Engineering is the skill of crafting effective instructions and questions to get optimal results from AI models."
      }
    ]
  },
  {
    moduleId: "devops",
    moduleTitle: "DevOps & Automation",
    questions: [
      {
        question: "What does CI/CD stand for?",
        options: [
          "Code Integration / Code Deployment",
          "Continuous Integration / Continuous Deployment",
          "Central Integration / Central Distribution",
          "Computer Integration / Computer Development"
        ],
        correctAnswer: 1,
        explanation: "CI/CD stands for Continuous Integration and Continuous Deployment - automating code testing and deployment processes."
      },
      {
        question: "What is Docker primarily used for?",
        options: [
          "Writing code",
          "Containerizing applications with their dependencies",
          "Creating databases",
          "Testing hardware"
        ],
        correctAnswer: 1,
        explanation: "Docker packages applications with all their dependencies into portable containers that run consistently across different environments."
      },
      {
        question: "What does Kubernetes do?",
        options: [
          "Writes application code",
          "Manages and orchestrates containers at scale",
          "Designs user interfaces",
          "Stores files"
        ],
        correctAnswer: 1,
        explanation: "Kubernetes orchestrates and manages containerized applications at scale, handling deployment, scaling, and operations."
      }
    ]
  }
];
