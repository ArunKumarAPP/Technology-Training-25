import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Search, Filter } from "lucide-react";
import * as Icons from "lucide-react";
import { curriculumModules } from "@/data/curriculumData";

const Curriculum = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = ["All", "Fundamentals", "Development", "Infrastructure", "Enterprise"];

  const getCategoryForModule = (moduleId: string): string => {
    if (["foundations", "dev-basics"].includes(moduleId)) return "Fundamentals";
    if (["frontend", "backend", "databases", "ui-ux"].includes(moduleId)) return "Development";
    if (["cloud", "devops", "security"].includes(moduleId)) return "Infrastructure";
    if (["enterprise", "industry"].includes(moduleId)) return "Enterprise";
    return "Other";
  };

  const filteredModules = curriculumModules.filter((module) => {
    const matchesSearch = 
      module.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      module.topics.some(topic => 
        topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        topic.description.toLowerCase().includes(searchTerm.toLowerCase())
      );

    const matchesCategory = 
      !selectedCategory || 
      selectedCategory === "All" ||
      getCategoryForModule(module.id) === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const getIcon = (iconName: string) => {
    const Icon = (Icons as any)[iconName];
    return Icon ? <Icon className="h-6 w-6" /> : null;
  };

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Comprehensive Curriculum
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            15 modules covering everything from legacy systems to emerging technologies.
            No technical jargon - just clear, practical knowledge for recruiters.
          </p>
        </div>

        {/* Search and Filter */}
        <Card className="mb-8 shadow-md">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search topics, keywords, technologies..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2 items-center">
                <Filter className="h-5 w-5 text-muted-foreground" />
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <Badge
                      key={cat}
                      variant={selectedCategory === cat || (!selectedCategory && cat === "All") ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => setSelectedCategory(cat === "All" ? null : cat)}
                    >
                      {cat}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Count */}
        <div className="mb-6 text-muted-foreground">
          Showing {filteredModules.length} of {curriculumModules.length} modules
        </div>

        {/* Modules */}
        <div className="space-y-6">
          {filteredModules.map((module) => (
            <Card key={module.id} className="shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-xl ${module.color} text-white shrink-0`}>
                    {getIcon(module.icon)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary">Module {module.number}</Badge>
                      <Badge variant="outline">{getCategoryForModule(module.id)}</Badge>
                    </div>
                    <CardTitle className="text-2xl mb-2">{module.title}</CardTitle>
                    <CardDescription>
                      {module.topics.length} topics covering fundamental to advanced concepts
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {module.topics.map((topic, idx) => (
                    <AccordionItem key={idx} value={`topic-${idx}`}>
                      <AccordionTrigger className="text-left font-semibold hover:text-primary">
                        {topic.title}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground leading-relaxed">
                        {topic.description}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredModules.length === 0 && (
          <Card className="py-12">
            <CardContent className="text-center">
              <p className="text-muted-foreground text-lg">
                No modules found matching your search criteria. Try different keywords or reset filters.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Curriculum;
